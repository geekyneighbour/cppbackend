#include "model.h"
#include <random>
#include <stdexcept>

namespace model {

// ================= RANDOM POINT =================
PointDouble GetRandomPointOnRoad(const Road& road) {
    static std::mt19937 gen(std::random_device{}());
    std::uniform_real_distribution<double> dist(0.0, 1.0);

    Point start = road.GetStart();
    Point end = road.GetEnd();

    if (road.IsHorizontal()) {
        double min_x = std::min(start.x, end.x);
        double max_x = std::max(start.x, end.x);
        return {min_x + dist(gen) * (max_x - min_x), (double)start.y};
    } else {
        double min_y = std::min(start.y, end.y);
        double max_y = std::max(start.y, end.y);
        return {(double)start.x, min_y + dist(gen) * (max_y - min_y)};
    }
}

// ================= MAP =================
void Map::AddOffice(Office office) {
    if (warehouse_id_to_index_.contains(office.GetId())) {
        throw std::invalid_argument("Duplicate warehouse");
    }

    size_t index = offices_.size();
    Office& o = offices_.emplace_back(std::move(office));

    try {
        warehouse_id_to_index_.emplace(o.GetId(), index);
    } catch (...) {
        offices_.pop_back();
        throw;
    }
}

// ================= GAME =================
void Game::AddMap(Map map) {
    size_t index = maps_.size();

    if (auto [it, inserted] = map_id_to_index_.emplace(map.GetId(), index); !inserted) {
        throw std::invalid_argument("Map already exists");
    }

    maps_.push_back(std::make_unique<Map>(std::move(map)));
}

// ================= SESSION =================
Dog& GameSession::AddDog(std::string_view name, bool randomize) {
    const auto& roads = map_->GetRoads();
    if (roads.empty()) {
        throw std::runtime_error("Map has no roads");
    }

    PointDouble spawn_pos;

    if (randomize) {

        std::uniform_int_distribution<size_t> dist(0, roads.size() - 1);
        const auto& road = roads[dist(random_gen_)];
        spawn_pos = GetRandomPointOnRoad(road);
    } else {

        const auto& first_road = roads[0];
        spawn_pos = {
            static_cast<double>(first_road.GetStart().x),
            static_cast<double>(first_road.GetStart().y)
        };
    }


    auto new_dog = std::make_unique<Dog>(std::string(name));
    new_dog->SetPos(spawn_pos.x, spawn_pos.y);
    
    dogs_.push_back(std::move(new_dog));
    return *dogs_.back();
}

Player& GameSession::AddPlayer(Dog& dog) {
    uint64_t id = ++next_player_id_;
    auto [it, ok] = players_.emplace(id, Player{id, &dog, this});
    return it->second;
}

std::vector<Player*> GameSession::GetPlayers() {
    std::vector<Player*> res;
    for (auto& [_, p] : players_) {
        res.push_back(&p);
    }
    return res;
}

void GameSession::UpdateState(double dt) {
    if (!map_) return;

    for (auto& dog : dogs_) {
        dog->UpdatePosition(dt, map_->GetRoads());
    }
}

// ================= GAME =================
GameSession& Game::FindOrCreateSession(const Map* map) {
    auto& ptr = sessions_[map];
    if (!ptr) {
        ptr = std::make_unique<GameSession>(map);
    }
    return *ptr;
}

const Map* Game::FindMap(const Map::Id& id) const {
    auto it = map_id_to_index_.find(id);
    if (it == map_id_to_index_.end()) return nullptr;
    return maps_[it->second].get();
}

const Game::Maps& Game::GetMaps() const noexcept {
    return maps_;
}

void Game::UpdateAllSessions(double dt) {
    for (auto& [_, session] : sessions_) {
        session->UpdateState(dt);
    }
}

// ================= DOG =================
void Dog::UpdatePosition(double dt, const std::vector<Road>& roads) {
    if (speed_.vx == 0.0 && speed_.vy == 0.0) return;

    double new_x = pos_.x + speed_.vx * dt;
    double new_y = pos_.y + speed_.vy * dt;


    double min_x = pos_.x, max_x = pos_.x;
    double min_y = pos_.y, max_y = pos_.y;

    bool found_road = false;

    for (const auto& road : roads) {

        double road_min_x = std::min(road.GetStart().x, road.GetEnd().x) - 0.4;
        double road_max_x = std::max(road.GetStart().x, road.GetEnd().x) + 0.4;
        double road_min_y = std::min(road.GetStart().y, road.GetEnd().y) - 0.4;
        double road_max_y = std::max(road.GetStart().y, road.GetEnd().y) + 0.4;

        if (pos_.x >= road_min_x && pos_.x <= road_max_x &&
            pos_.y >= road_min_y && pos_.y <= road_max_y) {
            
            if (!found_road) {

                min_x = road_min_x; max_x = road_max_x;
                min_y = road_min_y; max_y = road_max_y;
                found_road = true;
            } else {

                min_x = std::min(min_x, road_min_x);
                max_x = std::max(max_x, road_max_x);
                min_y = std::min(min_y, road_min_y);
                max_y = std::max(max_y, road_max_y);
            }
        }
    }


    if (!found_road) return;


    if (new_x < min_x) {
        new_x = min_x;
        speed_.vx = 0.0;
    } else if (new_x > max_x) {
        new_x = max_x;
        speed_.vx = 0.0;
    }

    if (new_y < min_y) {
        new_y = min_y;
        speed_.vy = 0.0;
    } else if (new_y > max_y) {
        new_y = max_y;
        speed_.vy = 0.0;
    }

    pos_ = {new_x, new_y};
}

// ================= ACTION =================
void Dog::SetAction(const std::string& action, double speed) {
    if (action.empty()) {
        speed_ = {0, 0};
        return;
    }

    if (action == "L") {
        speed_ = {-speed, 0};
        dir_ = Direction::WEST;
    } else if (action == "R") {
        speed_ = {speed, 0};
        dir_ = Direction::EAST;
    } else if (action == "U") {
        speed_ = {0, -speed};
        dir_ = Direction::NORTH;
    } else if (action == "D") {
        speed_ = {0, speed};
        dir_ = Direction::SOUTH;
    }
}

} // namespace model